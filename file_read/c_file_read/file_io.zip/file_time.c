#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>

int fileDateTimeStamp( char * );

int main( int argc, char *argv[] ) {
  if( argc != 2 ) {
    fprintf(stderr,"Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  fileDateTimeStamp(argv[1]);

  return 0;
}

int fileDateTimeStamp( char *fname ) {
  struct stat attrib;
  struct tm *clock;

  if( (stat(fname, &attrib)) == -1 ) {
    fprintf(stderr,"ABORT: cannot stat file: '%s'\n", fname);
    exit(1);
  }

  clock = localtime(&attrib.st_mtime);

  printf("year=%d\n", clock->tm_year + 1900);
  printf("month=%d\n", clock->tm_mon + 1);
  printf("month_day=%d\n", clock->tm_mday);
  printf("hour=%d\n", clock->tm_hour);
  printf("min=%d\n", clock->tm_min);
  printf("sec=%d\n", clock->tm_sec);
  return 0;
}

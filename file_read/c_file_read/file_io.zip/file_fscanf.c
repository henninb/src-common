#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int readFloats( char * );

int main( int argc, char *argv[] ) {
  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  readFloats(argv[1]);

  return 0;
}

int readFloats( char *fname ) {
  FILE *ifp;
  int int_val;

  /* float double_val; */
  float x = 0.0;
  float y = 0.0;
  float z = 0.0;

  if( (ifp = fopen(fname, "r")) == NULL ) {
    fprintf(stderr, "ABORT: fread failed.\n");
    exit(1);
  }

  fscanf(ifp, "%d", &int_val);
  printf("%d\n", int_val);

  fscanf(ifp, "%d", &int_val);
  printf("%d\n", int_val);

  if( fscanf(ifp, "%f %*c %f %*c %f", &x, &y, &z) != EOF ) {
  }
  //fscanf(ifp, "%f %*c", &double_val);
  //fscanf(ifp, "%f", &double_val);
  printf("y: %f\n", y);
  printf("x: %f\n", x);
  printf("z: %f\n", z);
  fclose(ifp);
  return 0;
}

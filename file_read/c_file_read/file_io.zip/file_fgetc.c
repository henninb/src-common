#include <stdio.h>
#include <stdlib.h>

int readChar( char * );

int main( int argc, char *argv[] ) {
  //FILE *ifp;
  //unsigned char ch;
  //int ch_count = 0;

  if( argc != 2 ) {
    fprintf(stderr,"Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  //if( (ifp = fopen(argv[1], "rb")) == NULL ) {
  //  fprintf(stderr, "ABORT: fopen failed.\n");
  //  exit(1);
  //}

  //while( !feof(ifp) ) {
  //while( (ch = fgetc(ifp)) != -1 ) {
  //  ch = fgetc(ifp);
  //  ch_count++;
  //  fprintf(stdout, "%c", ch);
  //}

  //fclose(ifp);

  //fprintf(stderr, "\nChar count for file: '%s' is %d\n", argv[1], ch_count);
  return 0;
}

int readChar( char *fname ) {
  FILE *ifp;
  unsigned char ch;
  int ch_count = 0;

  if( (ifp = fopen(fname, "rb")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed.\n");
    exit(1);
  }

  while( !feof(ifp) ) {
  //while( (ch = fgetc(ifp)) != -1 ) {
    ch = fgetc(ifp);
    ch_count++;
    fprintf(stdout, "%c", ch);
  }

  fclose(ifp);

  fprintf(stderr, "\nChar count for file: '%s' is %d\n", fname, ch_count);
  return 0;
}

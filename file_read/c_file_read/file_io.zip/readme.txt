SEEK_SET
Specifies that whence is a count of characters from the beginning of the file.

SEEK_CUR
Specifies that whence is a count of characters from the current file position. This count may be positive or negative.

SEEK_END
Specifies that whence is a count of characters from the end of the file. A negative count specifies a position within the current extent of the file; a positive count specifies a position past the current end. If you set the position past the current end, and actually write data, you will extend the file with zeros up to that position.

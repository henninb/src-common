#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUF_SIZE 200

void fileread( char *, char **, int );

int main( int argc, char *argv[] ) {
  //FILE *ifp;
  //char buffer[BUF_SIZE + 1];
  //int read_in = 0;
  //int count = 0;
  char *buffer;

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  fileread(argv[1], &buffer, BUF_SIZE);

  return 0;
}

void fileread( char *ifname, char **ostring, int ostring_sz ) {
  /* FILE *ofp; */
  int read_in = 0;

  /* ofp = stderr; */
  /* ifp = fopen(ifname, "rb") */

  FILE *ifp;

  *ostring = (char *) malloc(ostring_sz);
  memset(*ostring, '\0', ostring_sz);

  if( (ifp = fopen(ifname, "rb")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed for %s.\n", ifname);
    exit(1);
  }

  while( (read_in = fread(*ostring, sizeof(char *), ostring_sz, ifp)) > 0 ) {
    printf("here\n");
    //if( (fwrite(istring, 1, istring_sz, ifp)) == -1 ) {
    //fprintf(stderr, "ABORT: fwrite failed.\n");
    //exit(1);
  }

  printf("*ostring=%s\n", *ostring);
  printf("INFO: file open for %s complete.\n", ifname);
  fclose(ifp);
}

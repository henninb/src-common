#include <stdio.h>
#include <stdlib.h>

int appendc( char * );

int main( int argc, char *argv[] ) {
  //FILE *ofp;

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  appendc(argv[1]);

  return 0;
}

int appendc( char *fname ) {
  FILE *ofp;

  /* append to the end of the file */
  if( (ofp = fopen(fname, "wb")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed.\n");
    exit(1);
  }

  fputc(0, ofp);

  fclose(ofp);
  return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void filewrite( char *, char * );

int main( int argc, char *argv[] ) {
  FILE *ofp;

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
    exit(1);
  }

  /* append to the end of the file */
  if( (ofp = fopen(argv[1], "a")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed.\n");
    exit(1);
  }

  /* write to a file */
  if( (fwrite("navpass was called.\n", 1, strlen("navpass was called.\n"), ofp)) == -1 ) {
    fprintf(stderr, "ABORT: fwrite failed.\n");
    exit(1);
  }

  fclose(ofp);
  return 0;
}

void filewrite( char *ifname, char *istring ) {
  /* FILE *ofp; */

  /* ofp = stderr; */
  /* ifp = fopen(ifname, "rb") */

  FILE *ifp;

  if( (ifp = fopen(ifname, "wb")) == NULL ) {
  fprintf(stderr, "ABORT: fopen failed for %s.\n", ifname);
  exit(1);
  }

  if( (fwrite(istring, 1, strlen(istring), ifp)) == -1 ) {
  fprintf(stderr, "ABORT: fwrite failed.\n");
  exit(1);
  }

  printf("INFO: file open for %s complete.\n", ifname);
  fclose(ifp);
}

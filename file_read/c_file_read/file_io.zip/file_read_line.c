#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define MAX_STR_LEN 500
//typedef char string[MAX_STR_LEN];

void remove_newline( char * );
void readline( char *, void(*)() );
void process_line( char * );

int main( int argc, char *argv[] ) {
  if( argc != 2 ) {
    fprintf(stderr,"Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  readline(argv[1], process_line);
  return 0;
}

void process_line( char *line ) {
  printf("%s\n", line);
}

void readline( char *fname, void (*process_line)() ) {
  #define MAX_STR_LEN 5000
  //typedef char string[MAX_STR_LEN];
  FILE *ifp;
  char line[MAX_STR_LEN];

  if( (ifp = fopen(fname, "r")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed: %s.\n", fname);
    exit(1);
  }

  while( fgets(line, MAX_STR_LEN, ifp) != NULL ) {
    process_line(line);
  }

  fclose(ifp);
}

void remove_newline( char *str ) {
  char *new_line;

  if( (new_line = strstr(str, "\n")) != NULL ) {
    new_line[0] = '\0';
  }
}

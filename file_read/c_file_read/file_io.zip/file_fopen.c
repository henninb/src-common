#include <stdio.h>
#include <stdlib.h>

void fileopen( char * );

int main( int argc, char *argv[] ) {
  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  fileopen(argv[1]);
  return 0;
}

void fileopen( char *ifname ) {
  /* FILE *ofp; */

  /* ofp = stderr; */
  /* ifp = fopen(ifname, "rb") */

  FILE *ifp;

  if( (ifp = fopen(ifname, "r")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed for %s.\n", ifname);
    exit(1);
  }

  printf("INFO: file open for %s complete.\n", ifname);
  fclose(ifp);
}

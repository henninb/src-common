#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#define BLKSIZE 1024

int move_file( char *, char * );

int main( int argc, char *argv[] ) {
/*  char *new_file; */

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
    exit(1);
  }
  return 0;
}

int move_file( char *src, char *dest ) {
  char *src_path;
  char *dest_path;
  char *path;

  src_path = (char *) malloc(strlen(src) + BLKSIZE);
  dest_path = (char *) malloc(strlen(dest) + BLKSIZE);
  path = (char *) malloc(BLKSIZE);
  getcwd(path, BLKSIZE);
  sprintf(src_path, "%s\%s", path, src);
  sprintf(dest_path, "%s\%s", path, dest);
  if( rename(src_path,dest_path) == 0 ) {
    /* printf("%s\n", newpath); */
    free(src_path);
    free(dest_path);
    free(path);
    return 1;
  } else {
    printf("Cannot move file:%s\n", src);
  }
  free(src_path);
  free(dest_path);
  free(path);
  return 0;
}

#include <stdio.h>
#include <stdlib.h>

//#define MAX 100

/* get one line from the file */
int main( int argc, char *argv[] ) {
  FILE *ifp;
  char line[101];
  char *ch;

  if( argc != 2 ) {
    fprintf(stderr,"Usage: %s <ifname>\n", argv[0]);
    exit(1);
  }

  if( (ifp = fopen(argv[1], "r")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed.\n");
    exit(1);
  }

  do {
    if( (ch = fgets(line, 100, ifp)) != NULL ) {
      fprintf(stdout, "%s", line);
    }
  } while( ch != NULL );

  fclose(ifp);
  return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main( int argc, char *argv[] ) {
  int ifd;
  char ch;

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
    exit(1);
  }

  if( (ifd = open(argv[1], O_RDONLY)) == -1 ) {
    fprintf(stderr, "ABORT: open failed.\n");
    exit(1);
  }

  while( read(ifd, &ch, 1) != 0 ) {
    printf("%c", ch);
  }

  close(ifd);
  return 0;
}

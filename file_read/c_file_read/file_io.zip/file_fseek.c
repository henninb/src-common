#include <stdio.h>
#include <stdlib.h>

int main( int argc, char *argv[] ) {
  FILE *ifp;
  long length;

  if( argc != 2 ) {
    fprintf(stderr,"Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  if((ifp = fopen(argv[1], "r")) == NULL) {
    fprintf(stderr, "ABORT: fread failed.\n");
    exit(1);
  }

  /* fseek from the end of the file */
  if( fseek(ifp, 0L, SEEK_END) != 0 ) {
    fprintf(stderr, "ABORT: fseek failed.\n");
    fclose(ifp);
  }

  /* Find the length of the file. */
  if( (length = ftell(ifp)) == -1L ) {
    fprintf(stderr, "ABORT: ftell failed.\n");
    fclose(ifp);
    exit(1);
  }

  /* move back two from current position */
  if( fseek(ifp, -2, SEEK_CUR) != 0 ) {
    fprintf(stderr, "ABORT: fseek failed.\n");
    exit(1);
  }

  printf("File '%s' is %ld bytes, fseek from end of file.\n", argv[1], length);

  /* seek from the begining of a file */
  /* not sure if it works */
  if( fseek(ifp, 100L, SEEK_SET) != 0 ) {
    fprintf(stderr, "ABORT: fseek failed.\n");
    fclose(ifp);
    exit(1);
  }

  fclose(ifp);
  return 0;
}

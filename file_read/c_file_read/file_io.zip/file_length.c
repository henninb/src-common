#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

int main(int argc, char *argv[] ) {
  struct stat buf;

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <arg>", argv[0]);
    exit(1);
  }

  if( stat(argv[1], &buf) != 0 ) {
    fprintf(stderr, "ABORT: cannot stat file: '%s'\n", argv[1]);
    exit(1);
  }
  printf("size: %d\n", buf.st_size);
  return 0;
}

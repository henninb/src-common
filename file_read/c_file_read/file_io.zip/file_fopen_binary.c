#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE_MAX 500

/* note: try reading a windows formated text file */
int main( int argc, char *argv[] ) {
  FILE *ifp;
  char line[LINE_MAX];

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
    exit(1);
  }

  if( (ifp = fopen(argv[1], "rb")) == NULL ) {
    fprintf(stderr, "ABORT: fopen failed.\n");
    exit(1);
  }

  while( fgets(line, LINE_MAX, ifp) != NULL ) {
    if( strstr(line, "\r\n") != NULL ) {
      printf("INFO: cr nl found.\n");
    }
  }

  fclose(ifp);

  return 0;
}

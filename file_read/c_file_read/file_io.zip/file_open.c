#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int fileRead( char * );

int main( int argc, char *argv[] ) {
  //int ifd;
  //int ofd;
  //char ch;

  if( argc != 2 ) {
    fprintf(stderr, "Usage: %s <fname>\n", argv[0]);
    exit(1);
  }

  fileRead(argv[1]);
  return 0;
}

int fileRead( char *fname ) {
  int ifd;
  int ofd;
  char ch;

  if( (ifd = open(fname, O_RDONLY)) == -1 ) {
    fprintf(stderr, "ABORT: cannot open file for reading failed.: '%s'\n", fname);
    exit(1);
  }

  while( read(ifd, &ch, 1) != 0 ) {
    printf("%c", ch);
  }

  close(ifd);

  if( (ofd = open(fname, O_RDWR)) == -1 ) {
    fprintf(stderr, "ABORT: cannot open file for reading and writing: %s\n", fname);
    exit(1);
  }
  close(ofd);
  return 0;
}
